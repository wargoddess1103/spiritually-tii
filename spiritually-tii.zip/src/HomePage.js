export default function HomePage() {
  return (
    <div className="bg-[#FAF4EF] text-[#4A3F35] font-sans">
      <header className="text-center py-10 bg-[#F4E7D4] shadow-md">
        <h1 className="text-4xl font-bold tracking-wide">Spiritually Tii</h1>
        <p className="mt-2 text-lg italic">Guided readings for soul clarity</p>
      </header>

      <section className="px-6 py-12 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2 border-[#D8C2A4]">About</h2>
        <p>
          Welcome to Spiritually Tii, where intuition meets clarity. I’m Tii, a spiritual guide who offers personalized
          readings to help you navigate life’s questions, emotions, and energy shifts. With a grounded and empathetic
          approach, I’m here to support your journey.
        </p>
      </section>

      <section className="px-6 py-12 max-w-4xl mx-auto bg-[#FFF9F4]">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2 border-[#D8C2A4]">Services</h2>
        <ul className="space-y-4">
          <li>
            <strong>Intuitive Tarot Reading</strong> – 30-minute session focused on your current path and insights.
          </li>
          <li>
            <strong>Love & Relationship Reading</strong> – Heart-centered guidance for emotional clarity.
          </li>
          <li>
            <strong>Energy Alignment Session</strong> – Check-in with your chakras and energetic balance.
          </li>
        </ul>
      </section>

      <section className="px-6 py-12 max-w-4xl mx-auto">
        <h2 className="text-2xl font-semibold mb-4 border-b pb-2 border-[#D8C2A4]">Testimonials</h2>
        <div className="space-y-6">
          <blockquote className="bg-[#F4E7D4] p-4 rounded-xl shadow-sm">
            “Tii’s reading was spot-on. She helped me see what I was avoiding, and I left feeling more confident.”
            <footer className="mt-2 text-sm text-right">– Maya R.</footer>
          </blockquote>
          <blockquote className="bg-[#F4E7D4] p-4 rounded-xl shadow-sm">
            “Incredibly accurate and healing. I felt so seen and understood.”
            <footer className="mt-2 text-sm text-right">– Jordan T.</footer>
          </blockquote>
        </div>
      </section>

      <footer className="text-center py-6 text-sm bg-[#F4E7D4]">
        &copy; {new Date().getFullYear()} Spiritually Tii. All rights reserved.
      </footer>
    </div>
  );
}